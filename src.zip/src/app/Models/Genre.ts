export interface MovieGenre{
    genres: Genre[]
}
export interface Genre{
    id: string,
    name: string
}